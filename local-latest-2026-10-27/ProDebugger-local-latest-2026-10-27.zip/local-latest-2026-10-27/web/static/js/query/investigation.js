// Presentation model only: explicit assignments / assessments / recorded citations.
// A shared fid does not create an investigation edge or a supporting-evidence claim.
const array = x => Array.isArray(x) ? x : x == null ? [] : [x];
export function investigationBranches(scene) {
  const branches = scene.lanes.map(lane => ({
    id: lane.id, lane,
    windows: scene.windows.filter(w => [lane.anchor, ...(lane.cases || [])].includes(w.caseId)),
    queries: scene.events.filter(e => e.name === "query_logs" &&
      (e.lanes.includes(lane.id) || e.call?.arguments?.candidate_id === lane.agent)),
    candidates: scene.candidates.filter(c => c.lane === lane.id),
  }));
  for (const window of scene.windows) {
    if (!branches.some(b => b.windows.includes(window))) branches.push({id: window.id, lane: null, windows: [window], queries: [], candidates: []});
  }
  return branches;
}

export function candidateEvidence(scene, candidate) {
  const a = candidate.assessment || {}, selected = scene.root?.candidate === candidate.id;
  const result = selected ? scene.result || {} : {};
  const r = selected ? result.root || {} : {};
  const groups = [
    ["target", "Candidate location", candidate.fid == null ? [] : [candidate.fid], candidate.explicitFid ? "Explicit TRACE location" : "Located by step / module; not supporting evidence"],
    ["support", "Supporting reference", [...array(a.evidence_for), ...array(a.supporting_fids)], "Explicit TRACE citation"],
    ["counter", "Counterevidence reference", [...array(a.evidence_against), ...array(a.counterevidence)], "Explicit TRACE citation"],
    ["support", "Supporting reference", [...array(r.supporting_fids), ...array(result.supporting_evidence)], "Explicit SUBMIT citation"],
    ["counter", "Counterevidence reference", [...array(r.counterevidence), ...array(result.counterevidence)], "Explicit SUBMIT citation"],
  ];
  const refs = [];
  for (const [role, label, values, origin] of groups) for (const value of values) {
    const raw = typeof value === "object" && value ? value.fid ?? value.source_id ?? value : value;
    const fid = typeof raw === "number" ? raw : typeof raw === "string" && /^(?:f)?\d+$/.test(raw) ? Number(raw.replace(/^f/, "")) : null;
    const key = typeof raw === "object" ? JSON.stringify(raw) : String(raw);
    if (refs.some(x => x.role === role && x.key === key && x.origin === origin)) continue;
    refs.push({role, label, key, origin, fid, fact: scene.factById.get(fid) || null});
  }
  return refs;
}

export function evidencePoints(refs) {
  const byId = new Map();
  for (const ref of refs) {
    if (!ref.fact) continue;
    if (!byId.has(ref.fid)) byId.set(ref.fid, {fact: ref.fact, roles: []});
    if (!byId.get(ref.fid).roles.includes(ref.role)) byId.get(ref.fid).roles.push(ref.role);
  }
  return [...byId.values()];
}

export function candidateComparison(scene, candidate) {
  return (scene.result?.candidate_comparisons || []).find(x => x.candidate_id === candidate.candidateId)?.reasoning || "";
}

export function overviewStats(scene, branches) {
  return {
    branches: branches.length, queries: scene.events.filter(e => ["view", "view_evidence", "inspect", "query_logs"].includes(e.name)).length,
    candidates: scene.candidates.length, summaryNodes: 1 + branches.reduce((n, b) => n + b.windows.length + (b.lane ? 1 : 0) + b.candidates.length, 0),
    summaryEdges: branches.reduce((n, b) => n + (b.lane ? b.windows.length + b.candidates.length : 0), 0),
    factPoints: 0,
  };
}
