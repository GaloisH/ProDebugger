// On-demand point cloud: unique referenced facts, zero relationship lines.
import {ballPoint} from "./layout.js";

export function createEvidenceCloud(canvas, points, onPick) {
  const ctx = canvas.getContext("2d"), abort = new AbortController();
  const css = getComputedStyle(canvas);
  const colors = {base: css.getPropertyValue("--qg-ink-hi").trim(), target: css.getPropertyValue("--qg-focus").trim(),
    support: css.getPropertyValue("--qg-issue").trim(), counter: css.getPropertyValue("--qg-cand").trim(), bg: css.getPropertyValue("--qg-panel").trim()};
  let W = 0, H = 0, yaw = .4, pitch = .2, targets = [], drag = null, chosen = null;
  const positions = points.map((_, i) => points.length === 1 ? [0, 0, 0] : ballPoint(i + 1));
  function draw() {
    const dpr = Math.min(2, window.devicePixelRatio || 1), rect = canvas.getBoundingClientRect();
    W = rect.width; H = rect.height;
    canvas.width = W * dpr; canvas.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = colors.bg; ctx.fillRect(0, 0, W, H);
    targets = positions.map(([x, y, z], i) => {
      const a = x * Math.cos(yaw) + z * Math.sin(yaw), b = z * Math.cos(yaw) - x * Math.sin(yaw);
      const v = y * Math.cos(pitch) - b * Math.sin(pitch), depth = y * Math.sin(pitch) + b * Math.cos(pitch);
      const scale = Math.min(W, H) * .32 * 3 / (3 + depth);
      return {x: W / 2 + a * scale, y: H / 2 + v * scale, depth, i};
    }).sort((a, b) => b.depth - a.depth);
    for (const t of targets) {
      const point = points[t.i], role = point.roles.includes("target") ? "target" : point.roles.includes("counter") ? "counter" : point.roles.includes("support") ? "support" : "base";
      ctx.fillStyle = colors[role]; ctx.globalAlpha = chosen == null || chosen === t.i ? 1 : .35;
      const radius = chosen === t.i ? 7 : points.length > 120 ? 2.5 : 4.5;
      ctx.beginPath();
      if (role === "target") {
        ctx.moveTo(t.x, t.y - radius); ctx.lineTo(t.x + radius, t.y);
        ctx.lineTo(t.x, t.y + radius); ctx.lineTo(t.x - radius, t.y); ctx.closePath();
      } else ctx.arc(t.x, t.y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  canvas.addEventListener("pointerdown", e => { drag = {x: e.clientX, y: e.clientY, yaw, pitch, moved: false}; canvas.setPointerCapture(e.pointerId); }, {signal: abort.signal});
  canvas.addEventListener("pointermove", e => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
    if (drag.moved) { yaw = drag.yaw + dx * .008; pitch = Math.max(-1.4, Math.min(1.4, drag.pitch + dy * .008)); draw(); }
  }, {signal: abort.signal});
  canvas.addEventListener("pointerup", e => {
    if (drag && !drag.moved) {
      const rect = canvas.getBoundingClientRect(), x = e.clientX - rect.left, y = e.clientY - rect.top;
      const nearest = [...targets].sort((a, b) => Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y))[0];
      if (nearest && Math.hypot(nearest.x - x, nearest.y - y) < 20) { chosen = nearest.i; onPick(points[chosen]); draw(); }
    }
    drag = null;
  }, {signal: abort.signal});
  canvas.addEventListener("pointercancel", () => { drag = null; }, {signal: abort.signal});
  const observer = new ResizeObserver(draw); observer.observe(canvas); draw();
  return {destroy() { abort.abort(); observer.disconnect(); }};
}
