import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildQueryScene} from '../web/static/js/query/model.js';
import {investigationBranches, candidateEvidence, evidencePoints, candidateComparison, overviewStats} from '../web/static/js/query/investigation.js';
import {renderOverview} from '../web/static/js/query/overview.js';

const call = (ordinal, phase, name, args, data = {}) => ({event: 'committed', ordinal, phase, name, arguments: args, result: {data}});
function fixture({empty = false, ambiguous = false} = {}) {
  const candidate = {step: 2, module: 'plan', status: 'uncertain', output_quote: 'maybe clean to cool',
    proposition: '<script>untrusted</script>', evidence_for: [1, {fid: 999}], evidence_against: [2]};
  const record = {trajectory_id: 'fixture', task: 'cool a pot', task_type: 'alfworld', kinds: {}, relations: {}, entities: {}, goals: [],
    facts: [1, 2, 3].map(fid => ({fid, t: fid, slot: 'plan', rel: 'planned', args: [], value: `v${fid}`}))};
  const assignments = [{agent_id: 'a', anchor_case_id: 'anchor', question: 'Did cleaning establish cooling?'}];
  const toolCalls = [call(1, 'MANAGER', 'plan_trace', {assignments}),
    call(2, 'TRACE', 'query_logs', {candidate_id: 'a', sql: 'SELECT fid FROM evidence'}, {rows: [{fid: 3}], returned_steps: [3]}),
    call(3, 'TRACE', 'assess', {window_id: 'a', candidates: empty ? [] : [candidate], uncertainty: 'temperature unknown'})];
  if (ambiguous) {
    assignments.push({agent_id: 'b', anchor_case_id: 'anchor', question: 'Other investigation'});
    toolCalls.push(call(4, 'TRACE', 'assess', {window_id: 'b', candidates: [candidate]}));
  }
  return {record, evidences: {}, managerPlan: {}, traceQueries: [],
    routeCandidates: {windows: [{candidate_id: 'anchor', issue_step: 3, issue_fids: [3], hypothesis: 'not verified'}, {candidate_id: 'unassigned', issue_step: 1, issue_fids: [1]}]},
    result: empty ? {status: 'no_candidate'} : {root: {root_id: ambiguous ? null : 'trace-window:a:1', step: 2, module: 'plan', supporting_fids: [2]},
      supporting_evidence: [2], counterevidence: [], candidate_comparisons: [{candidate_id: 'trace-window:a:1', reasoning: 'recorded comparison'}]}, toolCalls};
}

test('branches follow explicit assignments; shared facts do not create new links', () => {
  const scene = buildQueryScene(fixture()), branches = investigationBranches(scene);
  assert.equal(branches.length, 2);
  assert.deepEqual(branches[0].windows.map(w => w.caseId), ['anchor']);
  assert.equal(branches[1].lane, null);
  assert.equal(branches[0].queries.length, 1);
  assert.equal(branches[0].candidates.length, 1);
  assert.equal(overviewStats(scene, branches).factPoints, 0);
});

test('retrieved facts are not silently promoted into supporting evidence', () => {
  const scene = buildQueryScene(fixture()), candidate = scene.candidates[0];
  const refs = candidateEvidence(scene, candidate);
  assert.ok(!refs.some(r => r.role === 'support' && r.fid === 3));
  assert.ok(refs.some(r => r.fid === 999 && r.fact === null));
  assert.equal(evidencePoints(refs).length, 2);
  assert.equal(candidate.status, 'uncertain');
  assert.ok(refs.find(r => r.role === 'target').origin.includes('not supporting evidence'));
});

test('ambiguous same-step same-module candidates are not arbitrarily selected', () => {
  const scene = buildQueryScene(fixture({ambiguous: true}));
  assert.equal(scene.root.candidate, null);
  for (const c of scene.candidates) assert.ok(!candidateEvidence(scene, c).some(r => r.origin.startsWith('SUBMIT')));
});

test('candidate comparisons use stable candidate identity, not step alone', () => {
  const scene = buildQueryScene(fixture({ambiguous: true}));
  assert.equal(candidateComparison(scene, scene.candidates[0]), 'recorded comparison');
  assert.equal(candidateComparison(scene, scene.candidates[1]), '');
});

test('initial overview draws no fact points and keeps source strings escaped', () => {
  const scene = buildQueryScene(fixture()), html = renderOverview(scene, ['runs', 'g', 'fixture'], investigationBranches(scene));
  assert.ok(!html.includes('<canvas'));
  assert.ok(!html.includes('<script>'));
  assert.ok(html.includes('&lt;script&gt;'));
  assert.ok(html.includes('Selection ≠ causal proof'));
  assert.ok(html.includes('uncertain'));
  assert.ok(html.includes('Overview: 0 fact points'));
  assert.doesNotMatch(html, /[\u3400-\u9fff]/);
  assert.ok(html.includes('未见已保存') === false);
});

test('empty candidate pools show no manufactured diagnosis', () => {
  const scene = buildQueryScene(fixture({empty: true}));
  const html = renderOverview(scene, ['runs', 'g', 'empty'], investigationBranches(scene));
  assert.equal(scene.root, null);
  assert.ok(html.includes('No candidate from this branch'));
  assert.ok(html.includes('No final diagnosis recorded'));
});

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const archive = path.join(root, 'artifacts/dsl_debugger/evidence-query-claims-n30-20261013');
for (const id of ['GPT-4o_013_alfworld_task_013', 'GPT-4o_024_alfworld_task_024', 'GPT-4o_003_chat_b000_t00_e02-1e119842']) {
  test(`real archived case preserves candidates, uncertainty and input: ${id}`, () => {
    const folder = path.join(archive, id);
    const json = name => JSON.parse(fs.readFileSync(path.join(folder, name), 'utf8'));
    const jsonl = name => fs.readFileSync(path.join(folder, name), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const input = {record: json('canonical_record.json'), evidences: json('evidences.json'), routeCandidates: json('route_candidates.json'),
      result: json('result.json'), managerPlan: json('manager_plan.json'), toolCalls: jsonl('tool_calls.jsonl'), traceQueries: jsonl('trace_queries.jsonl')};
    const original = JSON.stringify(input), scene = buildQueryScene(input), branches = investigationBranches(scene);
    assert.ok(scene.candidates.length > 0);
    assert.equal(scene.candidates.length, branches.reduce((n, b) => n + b.candidates.length, 0));
    for (const c of scene.candidates) {
      const refs = candidateEvidence(scene, c), points = evidencePoints(refs);
      assert.equal(points.length, new Set(points.map(p => p.fact.fid)).size);
      assert.equal(c.status, c.assessment.status);
    }
    assert.ok(renderOverview(scene, ['runs', 'group', id], branches).includes('0 fact points'));
    assert.equal(JSON.stringify(input), original);
    assert.ok(scene.root.candidate);
  });
}
