#!/bin/zsh
# Start this query-graph checkout locally. No model run is launched here.
set -eu
cd "$(dirname "$0")"
exec .venv/bin/python -B web/server.py "$@"
