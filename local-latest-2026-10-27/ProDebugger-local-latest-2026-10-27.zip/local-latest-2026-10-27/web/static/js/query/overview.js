// Default Query Graph: investigation summaries first; evidence is drawn only on demand.
import {esc, short, loader} from "../util.js";
import {getJSON} from "../api.js";
import {caseHref, queryHref} from "../routes.js";
import {CASES, DEFAULT_CASE} from "./cases.js";
import {loadQueryScene, factRepr, SLOT_LABEL} from "./model.js";
import {investigationBranches, candidateEvidence, evidencePoints, candidateComparison, overviewStats} from "./investigation.js";
import {createEvidenceCloud} from "./evidence-cloud.js";

const S = step => `S${String(step).padStart(2, "0")}`;
const text = value => typeof value === "string" ? value : JSON.stringify(value ?? "");
const label = c => `${S(c.step)} / ${c.module}`;
const chip = (value, tone = "") => `<span class="qi-chip ${tone}">${esc(value || "Not recorded")}</span>`;
const rawText = (value, cls = "") => `<p class="qi-prose ${cls}">${esc(text(value))}</p>`;
const disclosure = (title, value) => value ? `<details class="qi-disclosure"><summary>${esc(title)}</summary>${rawText(value)}</details>` : "";

function pointSample(fids, limit = 18) {
  if (fids.length <= limit) return fids;
  return Array.from({length: limit}, (_, i) => fids[Math.floor(i * (fids.length - 1) / (limit - 1))]);
}

function cloudGlyph({x, y, fids, id, role, selected = false, compact = false, selectable = true, label: title, detail = "", sub = ""}) {
  const color = role === "root" || role === "decision" ? "#76bd90" : role === "candidate" ? "#f0c878" : role === "lane" ? "#e69b70" : role === "window" ? "#b69ad1" : "#82a9d5";
  const radius = compact ? 29 : 42, sample = pointSample(fids), seed = [...id].reduce((n, c) => (n * 31 + c.charCodeAt(0)) >>> 0, 7);
  const dots = sample.map((_, i) => {
    const a = i * 2.399963 + (seed % 97) / 97 * 6.283, r = radius * (.2 + .55 * Math.sqrt((i + 1) / (sample.length + 1)));
    const dx = Math.cos(a) * r, dy = Math.sin(a) * r * .76;
    return `<circle class="qc-dot" cx="${(x + dx).toFixed(1)}" cy="${(y + dy).toFixed(1)}" r="${i % 4 === 0 ? 2.6 : 1.8}"/>`;
  }).join("");
  const labelY = y + radius + (compact ? 12 : 13);
  return `<g class="qc-node ${selected ? "is-selected" : ""}"${selectable ? ` role="button" tabindex="0" aria-label="${esc(title)}${detail ? `, ${esc(detail)}` : ""}" aria-pressed="false" data-select="${esc(role)}" data-id="${esc(id)}"` : ' role="img" aria-label="Route output summary"'} style="--qc-node:${color}">
    <circle class="qc-halo" cx="${x}" cy="${y}" r="${radius}"/>${dots}
    <circle class="qc-core" cx="${x}" cy="${y}" r="4"/>
    <text class="qc-title" x="${x}" y="${labelY}" text-anchor="middle">${esc(short(title, 25))}</text>
    <text class="qc-count" x="${x}" y="${labelY + 15}" text-anchor="middle">${esc(detail || `${sample.length} points`)}</text>
    ${sub ? `<text class="qc-sub" x="${x}" y="${labelY + 29}" text-anchor="middle">${esc(short(sub, 26))}</text>` : ""}
  </g>`;
}

function renderPointCloud(scene, ref, branches) {
  const compact = window.innerWidth < 760;
  const X = compact ? {record: 35, goal: 135, window: 235, lane: 335, candidate: 435, decision: 535, width: 570, radius: 29}
    : {record: 90, goal: 275, window: 465, lane: 675, candidate: 890, decision: 1095, width: 1180, radius: 42};
  const windows = [...new Map(branches.flatMap(b => b.windows).map(w => [w.id, w])).values()];
  const lanes = scene.lanes;
  const candidates = scene.candidates;
  const rowY = (i, n) => n <= 1 ? 245 : 130 + i * Math.min(175, 340 / (n - 1));
  const height = Math.max(480, Math.max(windows.length, lanes.length, candidates.length, 1) * 155 + 190);
  const recordIds = scene.facts.map(f => f.fid);
  const record = cloudGlyph({x: X.record, y: height / 2 - 12, fids: pointSample(recordIds, 18), id: "record", role: "record", compact, label: compact ? "DSL" : "DSL record", detail: `${recordIds.length} facts`, sub: `${scene.entities.length} entities`});
  const goal = cloudGlyph({x: X.goal, y: height / 2 - 12, fids: scene.goals.flatMap(g => g.facts), id: "goal", role: "record", compact, label: compact ? "Goal" : "Task goal", detail: `${scene.goals.length} goals`, sub: scene.goals[0]?.name || scene.meta.taskType});
  const windowNodes = windows.map((w, i) => cloudGlyph({x: X.window, y: rowY(i, windows.length), fids: w.fids, id: w.id, role: "window", compact, label: `${w.caseId} · ${S(w.step)}`, detail: `${w.fids.length} clues`, sub: compact ? "" : short(w.hypothesis, 26)})).join("");
  const laneNodes = lanes.map((lane, i) => cloudGlyph({x: X.lane, y: rowY(i, lanes.length), fids: lane.fids, id: lane.id, role: "lane", compact, label: short(lane.agent, compact ? 12 : 25), detail: `${lane.rows.length} SQL`, sub: compact ? "" : short(lane.question, 27)})).join("");
  const candidateNodes = candidates.map((c, i) => {
    const laneIndex = Math.max(0, lanes.findIndex(l => l.id === c.lane));
    const sameLane = candidates.filter(other => other.lane === c.lane), localIndex = sameLane.findIndex(other => other.id === c.id);
    const duplicates = candidates.filter(other => other.step === c.step && other.module === c.module);
    const suffix = duplicates.length > 1 ? (compact ? ` ·${laneIndex + 1}` : ` · ${short(lanes[laneIndex]?.agent || "lane", 16)}`) : "";
    const y = rowY(laneIndex, lanes.length) + (localIndex - (sameLane.length - 1) / 2) * 92;
    return cloudGlyph({x: X.candidate, y, fids: c.fid == null ? [] : [c.fid], id: c.id, role: "candidate", selected: scene.root?.candidate === c.id, compact, label: `${compact ? `S${c.step} ${c.module}` : label(c)}${suffix}`, detail: c.status, sub: compact ? "" : short(c.proposition, 28)});
  }).join("");
  const rootCandidate = candidates.find(c => scene.root?.candidate === c.id);
  const rootNode = scene.root ? cloudGlyph({x: X.decision, y: rootCandidate ? documentYForCandidate(rootCandidate, candidates, lanes) : height / 2 - 12,
    fids: [], id: "decision", role: "decision", compact, label: "SUBMIT", detail: compact ? `S${scene.root.step}` : `${S(scene.root.step)} · ${scene.root.module}`, sub: compact ? "" : scene.root.faultClass || scene.result?.status || "recorded choice"}) : "";
  const edges = [];
  const path = (x1, y1, x2, y2, from, to, cls = "") => {
    const start = x1 + X.radius, end = x2 - X.radius, bend = Math.max(14, (end - start) * .42);
    return `<path class="qc-edge ${cls}" data-from="${esc(from)}" data-to="${esc(to)}" d="M ${start} ${y1} C ${start + bend} ${y1}, ${end - bend} ${y2}, ${end} ${y2}"/>`;
  };
  edges.push(path(X.record, height / 2 - 12, X.goal, height / 2 - 12, "record", "goal", "qc-protocol"));
  for (const w of windows) edges.push(path(X.goal, height / 2 - 12, X.window, rowY(windows.indexOf(w), windows.length), "goal", w.id, "qc-route"));
  for (const lane of lanes) for (const w of windows) if (lane.anchor === w.caseId || (lane.cases || []).includes(w.caseId)) {
    edges.push(path(X.window, rowY(windows.indexOf(w), windows.length), X.lane, rowY(lanes.indexOf(lane), lanes.length), w.id, lane.id, "qc-assignment"));
  }
  for (const c of candidates) {
    const lane = lanes.find(l => l.id === c.lane);
    if (!lane) continue;
    const laneIndex = lanes.indexOf(lane), sameLane = candidates.filter(other => other.lane === c.lane), localIndex = sameLane.findIndex(other => other.id === c.id);
    const y = rowY(laneIndex, lanes.length) + (localIndex - (sameLane.length - 1) / 2) * 92;
    edges.push(path(X.lane, rowY(laneIndex, lanes.length), X.candidate, y, lane.id, c.id, "qc-assessment"));
  }
  if (rootCandidate) {
    const y = documentYForCandidate(rootCandidate, candidates, lanes);
    edges.push(path(X.candidate, y, X.decision, y, rootCandidate.id, "decision", "qc-submit"));
  }
  return `<header class="qi-header">
    <div><div class="qi-eyebrow">QUERY GRAPH <span>/ Evidence Investigation</span></div><h1>${esc(scene.meta.task || scene.meta.tid)}</h1>
      <div class="qi-context"><select aria-label="Case">${CASES.map(c => `<option value="${esc(queryHref(c.ref))}"${c.ref[1] === ref[2] ? " selected" : ""}>${esc(c.label)}</option>`).join("")}${CASES.some(c => c.ref[1] === ref[2]) ? "" : `<option selected>${esc(scene.meta.tid)}</option>`}</select>
      <span>${esc(scene.meta.taskType)} · ${scene.meta.steps} steps</span><a href="${caseHref(ref)}">Original trajectory ↗</a></div></div>
    <a class="qi-button qi-explore" href="${queryHref(ref.slice(1))}?view=legacy&mode=overview">Legacy call-by-call view ↗</a>
  </header>
  <div class="qi-contract"><span>PARSE → MAP → ROUTE → MANAGER → TRACE → SUBMIT</span>${chip(`Task goal: ${scene.goals[0]?.name || "Preserved"}`)}${chip(`${branches.length} investigation branches`)}${chip(`${candidates.length} candidates`)}</div>
  <section class="qc-panel" aria-label="Query point cloud">
    <div class="qc-head"><span>PARSE</span><span>MAP</span><span>ROUTE · Clues</span><span>MANAGER</span><span>TRACE</span><span>SUBMIT</span></div>
    <div class="qc-scroll"><svg class="qc-graph ${compact ? "is-compact" : ""}" viewBox="0 0 ${X.width} ${height}" style="--qc-radius:${X.radius}px" role="group" aria-label="Point-cloud workflow from task logs to diagnostic candidates">
      <defs><marker id="qc-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7" fill="none" stroke="currentColor" stroke-width="1"/></marker></defs>
      <g class="qc-edges">${edges.join("")}</g>
      ${record}${goal}${windowNodes}${laneNodes}${candidateNodes}${rootNode}
      <text class="qc-guide" x="${X.width / 2}" y="28" text-anchor="middle">Only recorded assignments, candidate links, and SUBMIT selections are connected</text>
    </svg></div>
    <div class="qc-legend">Each cloud shows up to 18 sample points. Select a node to inspect its record. Links show recorded assignments, candidate associations, and SUBMIT selections.</div>
  </section>
  <div class="qi-layout"><main class="qi-board"><section class="qi-verdict"><div class="qi-verdict-heading"><span class="qi-eyebrow">SUBMIT · Recorded decision</span>${scene.root ? chip(`Selected ${S(scene.root.step)} / ${scene.root.module}`) : chip("No selection recorded")}</div>
    <h2>${scene.root ? esc(scene.root.faultClass || "System-selected diagnostic hypothesis") : "No final diagnosis recorded"}</h2><p>${esc(short(scene.result?.reasoning || scene.root?.proposition || scene.result?.stop_reason || "Select a point cloud to inspect the saved evidence.", 245))}</p>
    <div class="qi-verdict-footer"><span>Selection ≠ causal proof${candidates.find(c => c.id === scene.root?.candidate)?.status === "uncertain" ? " · TRACE assessment remains uncertain" : ""}</span><button data-select="decision">Compare candidates and uncertainty ›</button></div></section>
    <details class="qi-history"><summary>View full access history <span>${scene.events.length} events</span></summary><ol>${scene.events.map((e, i) => `<li><button data-select="event" data-id="${i}"><span>${String(i + 1).padStart(2, "0")}</span><b>${esc(e.phase)}</b>${esc(e.title)}</button></li>`).join("")}</ol></details></main><aside class="qi-detail" aria-label="Evidence detail" hidden></aside></div>
  <footer class="qi-footer"><span>${scene.facts.length} source facts preserved · Select a record cloud to inspect</span><span>Only explicitly recorded workflow links are shown</span></footer>`;
}

function documentYForCandidate(candidate, candidates, lanes) {
  const laneIndex = Math.max(0, lanes.findIndex(l => l.id === candidate.lane));
  const sameLane = candidates.filter(c => c.lane === candidate.lane), localIndex = sameLane.findIndex(c => c.id === candidate.id);
  return rowYForCloud(laneIndex, lanes.length) + (localIndex - (sameLane.length - 1) / 2) * 92;
}
function rowYForCloud(i, n) { return n <= 1 ? 245 : 130 + i * Math.min(175, 340 / (n - 1)); }

export function renderOverview(scene, ref, branches) {
  const stats = overviewStats(scene, branches), selected = scene.candidates.find(c => c.id === scene.root?.candidate);
  const map = scene.events.find(e => e.phase === "MAP" && e.goal)?.goal;
  return `<header class="qi-header">
    <div><div class="qi-eyebrow">QUERY GRAPH <span>/ Diagnostic Investigation</span></div><h1>${esc(scene.meta.task || scene.meta.tid)}</h1>
      <div class="qi-context"><select aria-label="Case">${CASES.map(c => `<option value="${esc(queryHref(c.ref))}"${c.ref[1] === ref[2] ? " selected" : ""}>${esc(c.label)}</option>`).join("")}${CASES.some(c => c.ref[1] === ref[2]) ? "" : `<option selected>${esc(scene.meta.tid)}</option>`}</select>
      <span>${esc(scene.meta.taskType)} · ${scene.meta.steps} steps</span><a href="${caseHref(ref)}">Original trajectory ↗</a></div></div>
    <a class="qi-button qi-explore" href="${queryHref(ref.slice(1))}?view=cloud&mode=overview">Explore full point cloud ↗</a>
  </header>
  <div class="qi-contract"><span class="qi-contract-label">Investigation path</span><span>Task requirements</span><i>→</i><span>ROUTE clues</span><i>→</i><span>TRACE investigation</span><i>→</i><span>SUBMIT comparison</span>${map ? chip(`Goal state: ${map.state}`) : ""}</div>
  <div class="qi-record-strip">
    <button class="qi-record" data-select="record"><span class="qi-record-icon" aria-hidden="true">▦</span><span><strong>Shared evidence record</strong><small>${scene.facts.length} facts · ${scene.entities.length} entities · ${scene.goals.length} goals</small></span><span class="qi-record-open">Open ›</span></button>
    <div class="qi-summary"><strong>${stats.branches}</strong> investigation branches <span>·</span> <strong>${stats.candidates}</strong> TRACE candidates</div>
    <span class="qi-collapsed-note">${stats.queries} queries collapsed · Facts hidden in overview</span>
  </div>
  <div class="qi-layout"><main class="qi-board" aria-label="Investigation branches">
    <div class="qi-board-heading"><div><h2>Investigation branches</h2><p>Review the clues, investigation steps, and proposed candidates. Select a card to inspect its source evidence.</p></div><span>Only recorded assignments and assessments are shown</span></div>
    <div class="qi-column-head" aria-hidden="true"><span>ROUTE · Suspect clues</span><span></span><span>MANAGER / TRACE · Investigation</span><span></span><span>TRACE · Candidate explanations</span></div>
    <div class="qi-branches">${branches.map((b, i) => `<section class="qi-branch" data-branch="${esc(b.id)}" aria-label="Investigation ${i + 1}">
      <div class="qi-anchor-list">${b.windows.map(w => `<button class="qi-node qi-anchor" data-select="window" data-id="${esc(w.id)}"><span class="qi-node-kicker">Clue ${esc(w.caseId)}</span><strong>${S(w.step)} <span>issue anchor</span></strong><p>${esc(short(w.hypothesis || "No clue explanation recorded", 100))}</p><small>${w.fids.length} localization facts · Not a final root cause</small></button>`).join("") || '<div class="qi-empty-cell">No anchor links recorded</div>'}</div>
      <span class="qi-connector${b.lane && b.windows.length ? "" : " qi-no-connector"}" aria-label="Recorded assignment"></span>
      ${b.lane ? `<button class="qi-node qi-lane" data-select="lane" data-id="${esc(b.id)}"><span class="qi-node-kicker">Investigation ${String(i + 1).padStart(2, "0")}</span><strong>${esc(b.lane.agent)}</strong><p>${esc(short(b.lane.question || "No investigation question recorded", 150))}</p><small>${b.queries.filter(q => !q.error).length} successful SQL queries · ${b.lane.rows.length} rows <span>View investigation ›</span></small></button>` : '<div class="qi-empty-cell">No saved investigation assignment</div>'}
      <span class="qi-connector${b.lane && b.candidates.length ? "" : " qi-no-connector"}" aria-label="Recorded assessment"></span>
      <div class="qi-candidate-list">${b.candidates.map(c => `<button class="qi-node qi-candidate${scene.root?.candidate === c.id ? " is-chosen" : ""}" data-select="candidate" data-id="${esc(c.id)}"><span class="qi-node-kicker">${scene.root?.candidate === c.id ? "SUBMIT selected" : "TRACE candidate"}${chip(c.status, c.status === "uncertain" ? "qi-warn" : "")}</span><strong>${esc(label(c))}</strong><p>${esc(short(c.proposition || c.quote || "No explanation recorded", 115))}</p><small>${esc(c.faultClass || "Fault type unknown")} <span>View evidence ›</span></small></button>`).join("") || '<div class="qi-empty-cell">No candidate from this branch</div>'}</div>
    </section>`).join("") || '<p class="qi-empty">No saved investigation branches. The original trajectory and evidence record are still available.</p>'}</div>
    <section class="qi-verdict" aria-label="Recorded decision"><div class="qi-verdict-heading"><span class="qi-eyebrow">SUBMIT · Recorded decision</span>${scene.root ? chip(`Selected ${S(scene.root.step)} / ${scene.root.module}`) : chip(scene.result?.status || "No selection recorded")}</div>
      <h2>${scene.root ? esc(scene.root.faultClass || "System-selected diagnostic hypothesis") : "No final diagnosis recorded"}</h2>
      <p>${esc(short(scene.result?.reasoning || scene.root?.proposition || scene.result?.stop_reason || "Review the saved evidence in each branch.", 245))}</p>
      <div class="qi-verdict-footer"><span>Selection ≠ causal proof${selected?.status === "uncertain" ? " · Selected candidate remains uncertain in TRACE" : ""}</span><button data-select="decision">Review candidate comparison and uncertainty ›</button></div>
    </section>
    <details class="qi-history"><summary>View full access history <span>${scene.events.length} events</span></summary><ol>${scene.events.map((e, i) => `<li><button data-select="event" data-id="${i}"><span>${String(i + 1).padStart(2, "0")}</span><b>${esc(e.phase)}</b>${esc(e.title)}${e.error ? chip("rejected", "qi-warn") : ""}</button></li>`).join("")}</ol></details>
  </main><aside class="qi-detail" aria-label="Evidence detail" hidden></aside></div>
  <footer class="qi-footer"><span>Overview: 0 fact points · Shared fact cross-links are hidden</span><span>Source record preserved · Expand point clouds on demand</span></footer>`;
}

export function mountInvestigation(app, route) {
  const ref = ["runs", ...(route.ref || DEFAULT_CASE)];
  app.innerHTML = `<section class="qi">${loader("Preparing investigation branches…")}</section>`;
  const root = app.firstElementChild;
  let disposed = false, cloud = null, scene, input, branches, selection = null;
  const abort = new AbortController();
  const clearCloud = () => { cloud?.destroy(); cloud = null; };
  const sourceLink = step => `<a class="qi-source-link" href="${caseHref(ref, "trajectory", "step", step)}">View source trajectory S${String(step).padStart(2, "0")} ↗</a>`;
  const cloudButton = n => n ? `<button class="qi-button" data-cloud>Expand related point cloud · ${n} unique facts</button>` : "";
  const factButtons = (refs, role) => {
    const list = refs.filter(r => r.role === role);
    return list.length ? `<ul class="qi-evidence-list">${list.map(r => `<li>${r.fact ? `<button data-fact="${r.fid}"><strong>f${r.fid} · ${S(r.fact.t)} ${esc(SLOT_LABEL[r.fact.slot] || r.fact.slot)}</strong><span>${esc(short(factRepr(r.fact), 180))}</span><small>${esc(r.origin)}</small></button>` : `<div><strong>${esc(r.key)}</strong><small>${esc(r.origin)} · Not mapped to a DSL fact</small></div>`}</li>`).join("")}</ul>` : '<p class="qi-muted">No references of this type are listed separately; this does not mean related evidence is absent.</p>';
  };
  function locationFact(f) {
    const step = input?.steps?.find(s => s.t === f.t), module = SLOT_LABEL[f.slot];
    const source = module === "observation" ? step?.env_text : step?.parts?.[module];
    return `<section class="qi-source" aria-live="polite"><h3>f${f.fid} · ${S(f.t)} / ${esc(module || f.slot)}</h3><pre>${esc(factRepr(f))}</pre>${source ? `<details open><summary>Original module text</summary>${rawText(source)}</details>` : f.span ? rawText(f.span) : '<p class="qi-muted">No source excerpt is available for this record.</p>'}${sourceLink(f.t)}</section>`;
  }
  function candidateDetail(c) {
    const refs = candidateEvidence(scene, c), a = c.assessment || {};
    const points = evidencePoints(refs);
    return {title: label(c), subtitle: scene.root?.candidate === c.id ? "SUBMIT-selected candidate · Not causally verified" : "TRACE candidate · Not selected by SUBMIT", points,
      html: `<div class="qi-detail-tags">${chip(c.status, c.status === "uncertain" ? "qi-warn" : "")}${chip(c.faultClass || "Type unknown")}</div>
      <h3>Candidate explanation</h3>${rawText(c.proposition)}${c.quote ? `<blockquote>${esc(c.quote)}</blockquote>` : ""}${sourceLink(c.step)}
      <h3>Candidate localization</h3>${factButtons(refs, "target")}
      <h3>Supporting references <span>${refs.filter(r => r.role === "support").length}</span></h3>${factButtons(refs, "support")}
      <h3>Counterevidence references <span>${refs.filter(r => r.role === "counter").length}</span></h3>${factButtons(refs, "counter")}
      ${cloudButton(points.length)}
      <div class="qi-limit"><h3>Uncertainty</h3>${rawText(a.uncertainty || c.assessmentUncertainty || "Not recorded; this does not imply certainty.")}</div>
      ${disclosure("Full TRACE rationale (including narrative support and counterevidence)", a.reasoning)}
      ${disclosure("Immediate effect", a.immediate_effect)}${disclosure("SUBMIT comparison rationale", candidateComparison(scene, c))}`};
  }
  function queryDetail(event) {
    const q = event.call?.result?.data || {}, rows = q.rows || [];
    const limits = [q.partial && "Partial result", q.truncated && "Result truncated", ...(q.function_errors || []).map(text), ...(q.skipped_branches || []).map(text)].filter(Boolean);
    return `${limits.length ? `<div class="qi-limit">${limits.map(v => rawText(v)).join("")}<p>Unavailable branches do not mean zero matches.</p></div>` : ""}
      <details class="qi-disclosure"><summary>Raw SQL</summary><pre>${esc(event.sql || event.call?.arguments?.sql || "")}</pre></details>
      <details class="qi-disclosure"><summary>${rows.length} rows · Expand on demand</summary><p class="qi-muted">Returned rows are not automatically supporting evidence. Row counts across queries cannot be compared as diagnostic confidence.</p><div class="qi-query-rows">${rows.slice(0, 60).map(r => `<article><strong>${r.step != null ? esc(S(r.step)) : "Step not provided"} · ${esc(r.module || r.source_kind || "")}</strong><p>${esc(text(r.text ?? r))}</p></article>`).join("")}${rows.length > 60 ? `<p class="qi-muted">Showing the first 60 rows; the complete result remains in the original run log.</p>` : ""}</div></details>`;
  }
  function makeDetail(type, id) {
    if (type === "candidate") {
      const c = scene.candidates.find(c => c.id === id);
      return c && candidateDetail(c);
    }
    if (type === "window") {
      const w = scene.windows.find(w => w.id === id);
      if (!w) return;
      const refs = w.fids.map(fid => ({role: "target", fact: scene.factById.get(fid), fid, origin: "ROUTE issue_fids"})).filter(r => r.fact);
      return {title: `${w.caseId} · ${S(w.step)}`, subtitle: "ROUTE clue · Not a confirmed root cause", points: evidencePoints(refs), html: `<h3>Why this investigation started</h3>${rawText(w.hypothesis)}${sourceLink(w.step)}<h3>Explicitly linked localization facts</h3>${factButtons(refs, "target")}${cloudButton(refs.length)}`};
    }
    if (type === "lane") {
      const b = branches.find(b => b.id === id);
      if (!b?.lane) return;
      return {title: b.lane.agent, subtitle: "Investigation branch · Explicitly assigned, not inferred from shared facts", points: [], html: `<h3>What is being tested</h3>${rawText(b.lane.question)}
        <h3>Investigation anchors</h3><div class="qi-detail-choices">${b.windows.map(w => `<button data-select="window" data-id="${esc(w.id)}">${esc(w.caseId)} · ${S(w.step)}</button>`).join("") || '<p class="qi-muted">No anchor recorded.</p>'}</div>
        <h3>Queries</h3>${b.queries.map(q => q.error ? rawText(q.error.message || "Query rejected") : queryDetail(q)).join("") || '<p class="qi-muted">No saved successful SQL results found.</p>'}
        <h3>Proposed candidates</h3><div class="qi-detail-choices">${b.candidates.map(c => `<button data-select="candidate" data-id="${esc(c.id)}">${esc(label(c))} ${chip(c.status)}</button>`).join("") || '<p class="qi-muted">This branch proposed no candidates.</p>'}</div>`};
    }
    if (type === "decision") return {title: "SUBMIT candidate comparison", subtitle: "Reads the recorded decision; does not rerun the model", points: [], html: `<p class="qi-muted">A selected candidate may still be uncertain; a candidate not selected is not necessarily disproved.</p>
      ${scene.candidates.map(c => `<section class="qi-comparison"><button data-select="candidate" data-id="${esc(c.id)}"><strong>${esc(label(c))}</strong>${chip(scene.root?.candidate === c.id ? "Selected" : "Not selected")}${chip(c.status)}</button>${rawText(candidateComparison(scene, c) || "The recorded result contains no independent comparison rationale for this candidate.")}</section>`).join("") || '<p class="qi-muted">No TRACE candidates.</p>'}
      ${disclosure("Full SUBMIT rationale", scene.result?.reasoning)}<div class="qi-limit"><h3>Still unknown</h3>${rawText(scene.result?.uncertainty || "No separate uncertainty was recorded. Causality cannot be assumed to be verified.")}</div>`};
    if (type === "event") {
      const ev = scene.events[Number(id)];
      if (!ev) return;
      return {title: ev.title, subtitle: `${ev.phase} · Original access record`, points: [], html: `${rawText(ev.caption)}${ev.name === "query_logs" ? queryDetail(ev) : `<details class="qi-disclosure"><summary>Tool arguments and result</summary><pre>${esc(JSON.stringify(ev.call || ev, null, 2))}</pre></details>`}`};
    }
    if (type === "record") return {title: "Shared evidence record", subtitle: `${scene.facts.length} facts · All source data preserved`, points: scene.facts.map(fact => ({fact, roles: []})), html: `<p class="qi-muted">The record is shared input for every investigation, so it is not redrawn beside each query. The overview keeps the full point cloud collapsed.</p>
      <h3>Parsed goals</h3>${scene.goals.map(g => rawText(g.name || g.key)).join("") || '<p class="qi-muted">No structured goals recorded.</p>'}
      <a class="qi-button" href="${caseHref(ref, "graph")}">View full DSL record ↗</a>${cloudButton(scene.facts.length)}`};
  }
  function openDetail(type, id) {
    clearCloud();
    const detail = makeDetail(type, id);
    if (!detail) return;
    selection = {...detail, type, id};
    const panel = root.querySelector(".qi-detail");
    root.classList.add("has-detail"); panel.hidden = false;
    panel.innerHTML = `<div class="qi-detail-head"><div><span>${esc(detail.subtitle)}</span><h2>${esc(detail.title)}</h2></div><button class="qi-close" data-close aria-label="Close evidence detail">×</button></div><div class="qi-detail-body">${detail.html}<div class="qi-cloud-slot"></div><div class="qi-fact-slot"></div></div>`;
    root.querySelectorAll("[data-select][aria-pressed]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.select === type && b.dataset.id === id)));
    root.querySelectorAll(".qc-edge[data-from]").forEach(edge => edge.classList.toggle("is-active", edge.dataset.from === id || edge.dataset.to === id));
    if (window.innerWidth < 1180) panel.scrollIntoView({block: "start", behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"});
  }
  root.addEventListener("click", event => {
    const selectable = event.target.closest("[data-select]");
    if (selectable && scene) { openDetail(selectable.dataset.select, selectable.dataset.id); return; }
    const b = event.target.closest("button");
    if (!b || !scene) return;
    if (b.hasAttribute("data-close")) { clearCloud(); selection = null; root.classList.remove("has-detail"); root.querySelector(".qi-detail").hidden = true; root.querySelectorAll(".qi-node[aria-pressed]").forEach(n => n.setAttribute("aria-pressed", "false")); return; }
    if (b.dataset.fact) {
      const f = scene.factById.get(Number(b.dataset.fact));
      if (f) { root.querySelector(".qi-fact-slot").innerHTML = locationFact(f); root.querySelector(".qi-fact-slot").scrollIntoView({block: "nearest"}); }
    }
    if (b.hasAttribute("data-cloud") && selection) {
      const slot = root.querySelector(".qi-cloud-slot");
      if (cloud) { clearCloud(); slot.innerHTML = ""; b.textContent = `Expand related point cloud · ${selection.points.length} unique facts`; b.setAttribute("aria-expanded", "false"); return; }
      slot.innerHTML = `<section class="qi-cloud"><h3>Local evidence point cloud <span>${selection.points.length} points · 0 links</span></h3><canvas aria-label="On-demand evidence point cloud"></canvas><p>Drag to rotate; select a point to inspect its source. Spatial distance is for layout only, not causality or confidence.</p><div class="qi-cloud-key"><span>◇ Candidate location</span><span>● Supporting reference</span><span>● Counterevidence</span></div><div class="qi-cloud-readout" aria-live="polite"></div><details><summary>Select a fact from the list (keyboard accessible)</summary><div class="qi-cloud-list">${selection.points.map(p => `<button data-fact="${p.fact.fid}">f${p.fact.fid} · ${S(p.fact.t)} ${esc(SLOT_LABEL[p.fact.slot] || p.fact.slot)}</button>`).join("")}</div></details></section>`;
      cloud = createEvidenceCloud(slot.querySelector("canvas"), selection.points, p => {
        slot.querySelector(".qi-cloud-readout").textContent = `f${p.fact.fid} · ${S(p.fact.t)} ${SLOT_LABEL[p.fact.slot] || p.fact.slot}`;
        root.querySelector(".qi-fact-slot").innerHTML = locationFact(p.fact);
      });
      b.textContent = "Collapse point cloud"; b.setAttribute("aria-expanded", "true"); slot.scrollIntoView({block: "nearest"});
    }
  }, {signal: abort.signal});
  root.addEventListener("keydown", event => {
    if ((event.key === "Enter" || event.key === " ") && event.target.matches(".qc-node[role='button']")) {
      event.preventDefault(); openDetail(event.target.dataset.select, event.target.dataset.id);
    }
  }, {signal: abort.signal});
  root.addEventListener("change", e => { if (e.target.matches("select[aria-label='Case']") && e.target.value.startsWith("#/")) location.hash = e.target.value; }, {signal: abort.signal});
  Promise.all([loadQueryScene(ref), getJSON(ref, "input.json", null)]).then(([loaded, original]) => {
    if (disposed) return;
    scene = loaded; input = original; branches = investigationBranches(scene);
    root.innerHTML = `<section class="qi qi-cloud-page">${renderPointCloud(scene, ref, branches)}</section>`;
  }).catch(error => { if (!disposed) root.innerHTML = `<div class="error-box">Could not load investigation record: ${esc(error.message)} <a href="#/runs">View Runs</a></div>`; });
  return {unmount() { disposed = true; clearCloud(); abort.abort(); }};
}
